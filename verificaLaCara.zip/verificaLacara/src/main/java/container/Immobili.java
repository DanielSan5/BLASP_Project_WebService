package container;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import classes.Immobile;
import classes.QueryHandler;

/**
 * Servlet implementation class Immobili
 */
@WebServlet("/immobili")
public class Immobili extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Immobili() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.addHeader("Access-Control-Allow-Origin", "*");
		response.addHeader("Content-type", "application/json");
		response.addHeader("server", "verificaTps1");
		//output writer
		PrintWriter out = response.getWriter(); 
		QueryHandler queries = new QueryHandler();
		
		JsonObject risposta = new JsonObject();
		Gson g = new Gson();
		
		ArrayList<Immobile> immobili = new ArrayList<Immobile>();
		immobili = queries.getImmobili();
		
		if(immobili != null) {
			
			risposta.addProperty("result", "success");
			risposta.add("immobili", g.toJsonTree(immobili));
				
		}
		else {
			risposta.addProperty("result", "error");
		}
		out.println(risposta.toString());
		
		

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.addHeader("Access-Control-Allow-Origin", "*");
		response.addHeader("Access-Control-Allow-Methods", "POST");
		response.addHeader("Content-type", "application/json");
		response.addHeader("server", "verificaTps1");
		
		//output writer
		PrintWriter out = response.getWriter(); 
		//input reader
		BufferedReader in_body = request.getReader();

		StringBuilder sb = new StringBuilder();
		String line;
		String body;
	
		while((line = in_body.readLine()) != null) {
			sb.append(line);
		}
		
		body = sb.toString();
		Gson g = new Gson();
		JsonObject req = g.fromJson(body, JsonObject.class);
		QueryHandler queries = new QueryHandler();
		JsonObject risposta = new JsonObject();
		ArrayList<Immobile> immobili = new ArrayList<Immobile>();
		
		req.get("visure").getAsJsonArray().forEach((visura) -> {
			
			Immobile i = queries.getFiltered(visura.getAsJsonObject());
			if(i != null) {
				immobili.add(i);
			}else {
				risposta.addProperty("result", "error");
				out.println(risposta.toString());
				
			}
			
		});;
		
		risposta.addProperty("result", "success");
		risposta.add("immobili-filtrati", g.toJsonTree(immobili));
		out.println(risposta.toString());
	
		
		
		
	}


}
