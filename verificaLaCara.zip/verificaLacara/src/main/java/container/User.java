package container;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import classes.QueryHandler;
import de.mkammerer.argon2.Argon2;
import de.mkammerer.argon2.Argon2Factory;
import de.mkammerer.argon2.Argon2Factory.Argon2Types;

/**
 * Servlet implementation class User
 */
@WebServlet("/users")

public class User extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public User() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    private String passEncr(String password) {
    	
    	Argon2 argon2 = Argon2Factory.create(Argon2Types.ARGON2id);
    	String hash = argon2.hash(4, 1024 * 1024, 8, password);

    	return hash;
  
    	
    	
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setStatus(405);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.addHeader("Access-Control-Allow-Origin", "*");
		response.addHeader("Access-Control-Allow-Methods", "POST");
		response.addHeader("Content-type", "application/json");
		//output writer
		PrintWriter out = response.getWriter(); 
		//input reader
		BufferedReader in_body = request.getReader();
		
		StringBuilder sb = new StringBuilder();
		String line;
		String body;
		
		
		while((line = in_body.readLine()) != null) {
			sb.append(line);
		}
		
		body = sb.toString();
		
		Gson g = new Gson();
		JsonObject user = g.fromJson(body, JsonObject.class);
		
		String nome = user.get("nome").getAsString();
		String cognome = user.get("cognome").getAsString();
		String email = user.get("email").getAsString();
		String password = user.get("password").getAsString();
	
		QueryHandler queries = new QueryHandler();
		JsonObject risposta = new JsonObject();
		
		//controllo email gia esistente 0 se no, 1 se si, -1 errore sql
		int hasEmail =queries.hasEmail(email);
		if(hasEmail == 0) {
			
			String password_encr = passEncr(password);
			if(queries.inserisciUtente(nome, cognome, email, password_encr) != 1) {
				
				risposta.addProperty("result", "error");
				risposta.addProperty("error_code", "db_01");
				
			}else {
				risposta.addProperty("result", "success");
			}
			
			
		}else if(hasEmail == 1) {
			risposta.addProperty("result", "error");
			risposta.addProperty("error_code", "em_01");
		}else {
			risposta.addProperty("result", "error");
			risposta.addProperty("error_code", "db_02");
		}
		
		out.println(risposta.toString());
			
	}

}
