package classes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import com.google.gson.JsonObject;

public class QueryHandler {
	
    private static String db_url = "jdbc:mysql://localhost:3306/catasto";
    private static String db_driver = "com.mysql.jdbc.Driver";
    private static String db_user = "root";
    private static String db_password = "";
    private Connection conn;
  

	public QueryHandler() {
		
		try {
			Class.forName(db_driver);
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}
	
	private void establishConnection() {
		
		try{
			conn = DriverManager.getConnection(db_url, db_user, db_password); 
		}catch(SQLException e){
			System.err.println(e.getLocalizedMessage());
		}
		
	}
	
	public ArrayList<Immobile> getImmobili(){
		
		establishConnection();
		String prepared_query = "SELECT * FROM immobili";
		ArrayList<Immobile> immobili = new ArrayList<Immobile>();
		
		try(
			java.sql.PreparedStatement pr = conn.prepareStatement(prepared_query);
			){
			
			ResultSet res = pr.executeQuery();
			
			while(res.next()) {
				
				Immobile imm = new Immobile(res.getInt("FOGLIO"),  res.getInt("MAPPALE"), res.getInt("PARTICELLA"), res.getString("RENDITA"), res.getString("INDIRIZZO"), res.getInt("MQ"), res.getString("CF_PROPRIETARIO"));
				immobili.add(imm);
				
			}
			conn.close();
			return immobili;
			
		}catch(SQLException e) {
			e.printStackTrace();
			return null;
		}
		
		
	}
	
	public Immobile getFiltered(JsonObject visura) {
		
		
		establishConnection();
		String prepared_query = "SELECT * FROM immobili WHERE foglio = ? AND mappale = ? AND particella = ?";
		
		try(
			java.sql.PreparedStatement pr = conn.prepareStatement(prepared_query);
			){
			
			pr.setInt(1, visura.get("foglio").getAsInt());
			pr.setInt(2, visura.get("mappale").getAsInt());
			pr.setInt(3, visura.get("particella").getAsInt());
			ResultSet res = pr.executeQuery();
			
			if(res.next()) {
				
				Immobile imm = new Immobile(res.getInt("FOGLIO"),  res.getInt("MAPPALE"), res.getInt("PARTICELLA"), res.getString("RENDITA"), res.getString("INDIRIZZO"), res.getInt("MQ"), res.getString("CF_PROPRIETARIO"));
				conn.close();
				return imm;
			}
			return null;
		
		}catch(SQLException e){
			e.printStackTrace();
			System.out.println(e.getLocalizedMessage());
			return null;
		}
		
	}
	
	

	
	
	public int hasEmail(String email) {
		
		establishConnection();
		String prepared_query = "SELECT * FROM utenti WHERE EMAIL = ?";
		
		try(
			java.sql.PreparedStatement pr = conn.prepareStatement(prepared_query);
			){
			
			pr.setString(1, email);
			ResultSet res = pr.executeQuery();
			//se next false non ci sono righe -> quindi l'email è unica
			boolean check = res.next();
			conn.close();
			return check ? 1 : 0; //se check true 1 altrimenti 0
		
		}catch(SQLException e){
			e.printStackTrace();
			System.out.println(e.getLocalizedMessage());
			return -1;
		}
		
	}
	
	
	
	
	
	public int inserisciUtente(String nome, String cognome, String email, String password) {
		
		establishConnection();
		String prepared_query = "INSERT INTO utenti ( NOME, COGNOME, EMAIL, PASSWORD) VALUES (?, ?, ?, ?)";
		
		try(
				java.sql.PreparedStatement pr = conn.prepareStatement(prepared_query);
				){
				
				pr.setString(1, nome);
				pr.setString(2, cognome);
				pr.setString(3, email);
				pr.setString(4, password);
				
				//1 ok, 0 non ok
				int check = pr.executeUpdate();
				
				conn.close();
				
				return check;
			
			}catch(SQLException e){
				
				System.out.println(e.getLocalizedMessage());
				return -1;
			
			}
		
	}

}
