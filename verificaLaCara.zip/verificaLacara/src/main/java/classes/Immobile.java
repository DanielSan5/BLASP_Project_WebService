package classes;

public class Immobile {

	
	
	private int foglio;
	private int mappale;
	private int particella;
	private String rendita;
	private String indirizzo;
	private int mq;
	private String cf_proprieta;
	
	
	
	
	
	public Immobile(int foglio, int mappale, int particella, String rendita, String indirizzo, int mq,String cf_proprieta) {
		this.foglio = foglio;
		this.mappale = mappale;
		this.particella = particella;
		this.rendita = rendita;
		this.indirizzo = indirizzo;
		this.mq = mq;
		this.cf_proprieta = cf_proprieta;
	}





	@Override
	public String toString() {
		return "Immobile [foglio=" + foglio + ", mappale=" + mappale + ", particella=" + particella + ", rendita="
				+ rendita + ", indirizzo=" + indirizzo + ", mq=" + mq + ", cf_proprieta=" + cf_proprieta + "]";
	}
	
}
